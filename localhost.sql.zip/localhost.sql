-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 15, 2012 at 01:22 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `virtualwebdb`
--
CREATE DATABASE `virtualwebdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `virtualwebdb`;

-- --------------------------------------------------------

--
-- Table structure for table `absensi`
--

CREATE TABLE `absensi` (
  `id_absensi` int(10) NOT NULL auto_increment,
  `username` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `kelas` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `hari` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_absensi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `absensi`
--

INSERT INTO `absensi` (`id_absensi`, `username`, `kelas`, `hari`, `tanggal`, `keterangan`) VALUES
(1, 'JenuarDalapang', 'XA', 'Selasa', '2012-10-15', 'Hadir');

-- --------------------------------------------------------

--
-- Table structure for table `evaluasi`
--

CREATE TABLE `evaluasi` (
  `id_evaluasi` int(10) NOT NULL auto_increment,
  `topik` text character set latin1 collate latin1_general_ci NOT NULL,
  `soal` text character set latin1 collate latin1_general_ci NOT NULL,
  `jns_evaluasi` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') character set latin1 collate latin1_general_ci NOT NULL default 'Y',
  PRIMARY KEY  (`id_evaluasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `evaluasi`
--

INSERT INTO `evaluasi` (`id_evaluasi`, `topik`, `soal`, `jns_evaluasi`, `aktif`) VALUES
(1, 'Pengenalan HTML', '1. Tuliskan secara singkat sejarah HTML !<br>2. Tuliskan struktur dasar penulisan HTML !<br>3. Sebutkan 10 tag yang digunakan dalam HTML beserta fungsinya !<br>', 'Latihan 1', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `kbm`
--

CREATE TABLE `kbm` (
  `id_kbm` int(10) NOT NULL auto_increment,
  `topik` text character set latin1 collate latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_kbm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `kbm`
--

INSERT INTO `kbm` (`id_kbm`, `topik`, `aktif`) VALUES
(1, 'Pengenalan HTML', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `kuis`
--

CREATE TABLE `kuis` (
  `id_kuis` int(10) NOT NULL auto_increment,
  `topik` text character set latin1 collate latin1_general_ci NOT NULL,
  `pertanyaan` text character set latin1 collate latin1_general_ci NOT NULL,
  `pilihan_a` text character set latin1 collate latin1_general_ci NOT NULL,
  `pilihan_b` text character set latin1 collate latin1_general_ci NOT NULL,
  `pilihan_c` text character set latin1 collate latin1_general_ci NOT NULL,
  `pilihan_d` text character set latin1 collate latin1_general_ci NOT NULL,
  `jawaban` varchar(10) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_kuis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `kuis`
--

INSERT INTO `kuis` (`id_kuis`, `topik`, `pertanyaan`, `pilihan_a`, `pilihan_b`, `pilihan_c`, `pilihan_d`, `jawaban`) VALUES
(1, 'Pengenalan HTML', 'HTML singkatan dari', 'Hypertext Markup Language', 'Hypertext Manual Language', 'Hypertext Marking Language', 'Hypertext Mask Language', 'a'),
(2, 'Pengenalan HTML', 'Instruksi pada HTML selalu dimulai dengan', 'Tab', 'Tag', 'Tas', 'Tar', 'b'),
(3, 'Pengenalan HTML', 'Perintah tag b membuat tulisan menjadi', 'Rata Kanan', 'Miring', 'Rata Kiri', 'Tebal', 'd'),
(4, 'Pengenalan HTML', 'Perintah yang menyebabkan teks berjalan dari kanan ke kiri ialah', 'Title', 'Body', 'Marquee', 'Head', 'c'),
(5, 'Pengenalan HTML', 'Atribut WIDTH dan HEIGHT pada tag IMG SRC digunakan untuk', 'Mengatur ukuran gambar', 'Mengatur resolusi gambar', 'Mengatur warna gambar', 'Mengatur lebar gambar', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `media_kbm`
--

CREATE TABLE `media_kbm` (
  `id_media` int(10) NOT NULL auto_increment,
  `topik` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `media` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_media`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `media_kbm`
--

INSERT INTO `media_kbm` (`id_media`, `topik`, `media`) VALUES
(1, 'Pengenalan HTML', 'apaituhtml.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `modul_kbm`
--

CREATE TABLE `modul_kbm` (
  `id_modul` int(10) NOT NULL auto_increment,
  `topik` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `modul` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_modul`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `modul_kbm`
--

INSERT INTO `modul_kbm` (`id_modul`, `topik`, `modul`) VALUES
(1, 'Pengenalan HTML', 'pengenalanhtml.txt');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_evaluasi`
--

CREATE TABLE `nilai_evaluasi` (
  `id_nilaievaluasi` int(10) NOT NULL auto_increment,
  `username` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `nilai_evaluasi` varchar(10) character set latin1 collate latin1_general_ci NOT NULL,
  `kelas` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `jns_evaluasi` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_nilaievaluasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `nilai_evaluasi`
--

INSERT INTO `nilai_evaluasi` (`id_nilaievaluasi`, `username`, `nilai_evaluasi`, `kelas`, `jns_evaluasi`) VALUES
(1, 'JenuarDalapang', '95', 'XA', 'Latihan 1');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_kuis`
--

CREATE TABLE `nilai_kuis` (
  `id_nilaikuis` int(10) NOT NULL auto_increment,
  `username` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `nilai_kuis` varchar(10) character set latin1 collate latin1_general_ci NOT NULL,
  `kelas` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `topik` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_nilaikuis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nilai_kuis`
--


-- --------------------------------------------------------

--
-- Table structure for table `source_kbm`
--

CREATE TABLE `source_kbm` (
  `id_source` int(10) NOT NULL auto_increment,
  `topik` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `source` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_source`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `source_kbm`
--

INSERT INTO `source_kbm` (`id_source`, `topik`, `source`) VALUES
(1, 'Pengenalan HTML', 'pengenalanhtml.html');

-- --------------------------------------------------------

--
-- Table structure for table `topik_kuis`
--

CREATE TABLE `topik_kuis` (
  `id_topik` int(10) NOT NULL auto_increment,
  `topik` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') character set latin1 collate latin1_general_ci NOT NULL default 'Y',
  PRIMARY KEY  (`id_topik`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `topik_kuis`
--

INSERT INTO `topik_kuis` (`id_topik`, `topik`, `aktif`) VALUES
(1, 'Pengenalan HTML', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(10) NOT NULL auto_increment,
  `username` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `password` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) character set latin1 collate latin1_general_ci NOT NULL,
  `kelas` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `level` varchar(50) character set latin1 collate latin1_general_ci NOT NULL,
  `aktif` enum('Y','N') character set latin1 collate latin1_general_ci NOT NULL default 'Y',
  PRIMARY KEY  (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama_lengkap`, `kelas`, `level`, `aktif`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', '', 'admin', 'Y'),
(2, 'JenuarDalapang', 'a16233e7757d162117dc123d4f8c7f26', 'Jenuar Dalapang', 'XA', 'user', 'Y');
